import os
import sys
import ctypes
import shutil
import subprocess

def is_admin():
    """Verifica se lo script è in esecuzione come amministratore."""
    try:
        return ctypes.windll.shell32.IsUserAnAdmin()
    except:
        return False

def run_as_admin():
    """Riavvia lo script come amministratore."""
    script = sys.executable
    params = " ".join([f'"{arg}"' for arg in sys.argv])
    ctypes.windll.shell32.ShellExecuteW(None, "runas", script, params, None, 1)
    sys.exit()

if not is_admin():
    print("Riavvio dello script con privilegi di amministratore...")
    run_as_admin()

def get_available_drives():
    from string import ascii_uppercase
    return [f"{d}:" for d in ascii_uppercase if os.path.exists(f"{d}:/") and d != "C"]

def choose_drive(drives):
    print("Seleziona il disco su cui installare GRUB:")
    for i, drive in enumerate(drives):
        print(f"[{i}] {drive}")
    while True:
        try:
            choice = int(input("Inserisci il numero del disco: "))
            if 0 <= choice < len(drives):
                confirm = input(f"Sei sicuro di voler installare GRUB su {drives[choice]}? (y/n): ").strip().lower()
                if confirm == 'y':
                    return drives[choice]
        except ValueError:
            pass
        print("Scelta non valida. Riprova.")

def install_grub(drive):
    installer_path = os.path.abspath("installer/grub-install.exe")
    command = [
        installer_path, "--force", "--removable", "--no-floppy", "--target=x86_64-efi",
        f"--boot-directory={drive}/boot", f"--efi-directory={drive}/"
    ]
    print("Eseguendo:", " ".join(command))
    subprocess.run(command, shell=True)

def copy_files(drive):
    try:
        os.makedirs(f"{drive}/boot/grub/themes", exist_ok=True)
        shutil.copy("grub.cfg", f"{drive}/boot/grub/grub.cfg")
        shutil.copytree("volploader", f"{drive}/boot/grub/themes/volploader", dirs_exist_ok=True)
        print("File copiati con successo!")
    except Exception as e:
        print("Errore nella copia dei file:", e)

def main():
    drives = get_available_drives()
    if not drives:
        print("Nessun disco disponibile!")
        return
    selected_drive = choose_drive(drives)
    install_grub(selected_drive)
    copy_files(selected_drive)
    print("Installazione completata!")

if __name__ == "__main__":
    main()