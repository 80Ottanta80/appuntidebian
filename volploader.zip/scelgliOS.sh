#!/bin/bash

# File di configurazione di GRUB
GRUB_CFG="/boot/grub/grub.cfg"

# Estrai la lista dei sistemi operativi disponibili
OS_LIST=$(grep -oP 'menuentry \K.*' "$GRUB_CFG" | sed "s/'//g")

# Controlla se la lista è vuota
if [ -z "$OS_LIST" ]; then
    echo "Nessun sistema operativo trovato!"
    exit 1
fi

# Mostra la lista dei sistemi operativi
echo "Sistemi operativi disponibili:"
echo "$OS_LIST" | nl -v 0

# Chiedi all'utente di selezionare un sistema operativo
read -p "Seleziona il numero del sistema operativo da avviare al prossimo riavvio: " OS_NUM

# Verifica che l'input sia un numero valido
if ! [[ "$OS_NUM" =~ ^[0-9]+$ ]]; then
    echo "Input non valido. Inserisci un numero."
    exit 1
fi

# Ottieni il nome del sistema operativo selezionato
SELECTED_OS=$(echo "$OS_LIST" | sed -n "$((OS_NUM + 1))p")

# Imposta il sistema operativo selezionato come predefinito per il prossimo riavvio
grub-reboot "$OS_NUM"

# Conferma all'utente
echo "Il sistema operativo '$SELECTED_OS' sarà avviato al prossimo riavvio."